package com.dxcflix.tweaker

import rikka.shizuku.Shizuku

/** Runs shell commands with adb-shell permission through Shizuku. */
object Shell {

    fun run(script: String): String {
        return try {
            // Shizuku.newProcess is not public in newer API versions, so call it by reflection.
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val full = "exec 2>&1\n$script"
            val p = m.invoke(null, arrayOf("sh", "-c", full), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim().ifEmpty { "(OK)" }
        } catch (e: Throwable) {
            "ERROR: ${e.cause?.message ?: e.message}"
        }
    }
}
