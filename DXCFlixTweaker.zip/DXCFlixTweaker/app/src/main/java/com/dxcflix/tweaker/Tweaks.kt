package com.dxcflix.tweaker

/**
 * One toggle = one group of commands.
 * ON  -> `on` commands  (taken from the run scripts)
 * OFF -> `off` commands (taken from the stop scripts)
 */
data class Tweak(
    val id: String,
    val group: String,
    val title: String,
    val desc: String,
    val on: List<String>,
    val off: List<String>
)

const val FF = "com.dts.freefireth"
const val FF_MAX = "com.dts.freefiremax"

val TWEAKS: List<Tweak> = listOf(

    // ---------------- DXC (dxc.sh / undxc.sh) ----------------
    Tweak(
        "touch", "Display & Touch (dxc)", "Touch response / pointer speed",
        "pointer_speed 7, long-press 150ms, multi-press 150ms",
        on = listOf(
            "settings put system pointer_speed 7",
            "settings put secure touch_acceleration 1",
            "settings put secure long_press_timeout 150",
            "settings put secure multi_press_timeout 150"
        ),
        off = listOf(
            "settings put system pointer_speed 0",
            "settings delete secure touch_acceleration",
            "settings put secure long_press_timeout 400",
            "settings put secure multi_press_timeout 300"
        )
    ),
    Tweak(
        "anim", "Display & Touch (dxc)", "Animation speed 0.5x",
        "window / transition / animator scale 0.5  (OFF = 1.0x)",
        on = listOf(
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5"
        ),
        off = listOf(
            "settings put global window_animation_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global animator_duration_scale 1.0"
        )
    ),
    Tweak(
        "power", "Battery & Network (dxc)", "Disable power saving",
        "low_power_mode 0, low_power_mode_sticky 0",
        on = listOf(
            "settings put global low_power_mode 0",
            "settings put global low_power_mode_sticky 0"
        ),
        off = listOf(
            "settings delete global low_power_mode_sticky"
        )
    ),
    Tweak(
        "net", "Battery & Network (dxc)", "Network optimization",
        "mobile_data_always_on 1, network_scoring_ui_enabled 0",
        on = listOf(
            "settings put global mobile_data_always_on 1",
            "settings put global network_scoring_ui_enabled 0"
        ),
        off = listOf(
            "settings delete global mobile_data_always_on",
            "settings delete global network_scoring_ui_enabled"
        )
    ),
    Tweak(
        "ffprio", "Priority (dxc)", "Free Fire priority",
        "standby bucket: active  (OFF = working_set)",
        on = listOf(
            "am set-standby-bucket $FF active 2>/dev/null",
            "am set-standby-bucket $FF_MAX active 2>/dev/null"
        ),
        off = listOf(
            "am set-standby-bucket $FF working_set 2>/dev/null",
            "am set-standby-bucket $FF_MAX working_set 2>/dev/null"
        )
    ),
    Tweak(
        "helpers", "Priority (dxc)", "Brevent + AShell priority",
        "standby bucket: active  (OFF = working_set)",
        on = listOf(
            "am set-standby-bucket me.piebridge.brevent active 2>/dev/null",
            "am set-standby-bucket in.sunilpaulmathew.ashell active 2>/dev/null"
        ),
        off = listOf(
            "am set-standby-bucket me.piebridge.brevent working_set 2>/dev/null",
            "am set-standby-bucket in.sunilpaulmathew.ashell working_set 2>/dev/null"
        )
    ),

    // ---------------- V6 (v6.sh / unv6.sh) ----------------
    Tweak(
        "v6", "V6 (v6.sh)", "V6 aim / touch values",
        "aim_lock_sensitivity 0.98, touch_responsiveness 1",
        on = listOf(
            "settings put system aim_lock_sensitivity 0.98",
            "settings put system touch_responsiveness 1"
        ),
        off = listOf(
            "settings delete system aim_lock_sensitivity",
            "settings delete system touch_responsiveness",
            "settings delete global activity_manager_constants",
            "cmd power set-mode 0",
            "settings put global low_power_trigger_level 15",
            "settings put global adaptive_battery_management_enabled 1",
            "settings delete global hardware_accelerated",
            "settings delete global show_background_blur_values",
            "settings delete global updatable_driver_all_apps",
            "cmd thermalservice reset",
            "settings put global thermal_mitigation_ready 1",
            "settings delete global view.touch_slop",
            "settings delete global view.scroll_friction"
        )
    ),

    // ---------------- CORE (mor.sh / antmor.sh) ----------------
    Tweak(
        "hw", "Core tweaks (mor.sh)", "Hardware acceleration overrides",
        "hardware_acceleration_filter, hwui / gr / fimg2d props",
        on = listOf(
            "settings put global hardware_acceleration_filter 1",
            "settings put system hardware_acceleration true",
            "setprop debug.hwui.profile.dirirty_regions false",
            "setprop debug.gr.numframestodrop 0",
            "setprop debug.fimg2d.linear_scaling 1"
        ),
        off = listOf(
            "settings delete global hardware_acceleration_filter",
            "settings delete system hardware_acceleration",
            "setprop debug.hwui.profile.dirirty_regions \"\"",
            "setprop debug.gr.numframestodrop \"\"",
            "setprop debug.fimg2d.linear_scaling \"\""
        )
    ),
    Tweak(
        "compact", "Core tweaks (mor.sh)", "App compaction",
        "activity_manager compact_action_1/2 = full, use_compaction",
        on = listOf(
            "cmd device_config put activity_manager compact_action_1 full",
            "cmd device_config put activity_manager compact_action_2 full",
            "cmd device_config put activity_manager use_compaction true"
        ),
        off = listOf(
            "cmd device_config delete activity_manager compact_action_1",
            "cmd device_config delete activity_manager compact_action_2",
            "cmd device_config delete activity_manager use_compaction"
        )
    ),
    Tweak(
        "storage", "Core tweaks (mor.sh)", "Storage / sqlite",
        "sqlite journalmode PERSIST, synchronous OFF, sys_storage_preload",
        on = listOf(
            "setprop debug.sqlite.journalmode PERSIST",
            "setprop debug.sqlite.synchronous OFF",
            "settings put global sys_storage_preload 1"
        ),
        off = listOf(
            "setprop debug.sqlite.journalmode \"\"",
            "setprop debug.sqlite.synchronous \"\"",
            "settings delete global sys_storage_preload"
        )
    ),
    Tweak(
        "logs", "Core tweaks (mor.sh)", "VM / logcat silencer",
        "log.tag.* props, extservices log_level",
        on = listOf(
            "setprop log.tag.dalvikvm NUM",
            "setprop log.tag.ArtMethod NONE",
            "setprop log.tag.all NONE",
            "cmd extservices set-extension-property log_level NONE"
        ),
        off = listOf(
            "setprop log.tag.dalvikvm \"\"",
            "setprop log.tag.ArtMethod \"\"",
            "setprop log.tag.all \"\"",
            "cmd extservices set-extension-property log_level DEFAULT"
        )
    ),
    Tweak(
        "sf", "Core tweaks (mor.sh)", "SurfaceFlinger / scrolling",
        "sf.disable_hwc 0, predict_hwc strategy, scrolling_cache 3",
        on = listOf(
            "setprop debug.sf.disable_hwc 0",
            "setprop debug.sf.predict_hwc_composition-strategy 1",
            "settings put global scrolling_cache 3"
        ),
        off = listOf(
            "setprop debug.sf.disable_hwc \"\"",
            "setprop debug.sf.predict_hwc_composition-strategy \"\"",
            "settings delete global scrolling_cache"
        )
    ),
    Tweak(
        "timeouts", "Core tweaks (mor.sh)", "Component timeouts",
        "short_component_timeout 1000, service_background_timeout 10000",
        on = listOf(
            "cmd device_config put activity_manager short_component_timeout 1000",
            "cmd device_config put activity_manager service_background_timeout 10000"
        ),
        off = listOf(
            "cmd device_config delete activity_manager short_component_timeout",
            "cmd device_config delete activity_manager service_background_timeout"
        )
    )
)

// ---------------- One-tap actions (not toggles) ----------------

const val RAM_CLEAN_SCRIPT =
    "sync\n" +
    "am kill-all\n" +
    "cmd activity kill-all\n" +
    "pm trim-caches 999G"

const val INFO_SCRIPT =
    "echo \"Model   : \$(getprop ro.product.model)\"\n" +
    "echo \"Brand   : \$(getprop ro.product.brand)\"\n" +
    "echo \"Android : \$(getprop ro.build.version.release)\"\n" +
    "wm size\n" +
    "wm density\n" +
    "grep MemTotal /proc/meminfo\n" +
    "grep MemAvailable /proc/meminfo"

/** Packages that must never be force-stopped. */
val KEEP_PACKAGES = listOf(
    FF, FF_MAX,
    "me.piebridge.brevent",
    "in.sunilpaulmathew.ashell",
    "com.android.systemui",
    "com.android.settings",
    "com.google.android.gms",
    "com.google.android.gsf",
    "com.evozi.injector",
    "com.rjctunnel.vpn",
    "net.androidtechvilla.edoztunnelpro",
    "com.fast.free.unblock.secure.vpn",
    "com.netmod.syna",
    "com.tlsvpn.tlstunnel",
    "moe.shizuku.privileged.api",
    "com.dxcflix.tweaker"
)

fun forceStopScript(): String {
    val pat = KEEP_PACKAGES.joinToString("|")
    return "for pkg in \$(pm list packages -3 | cut -f 2 -d ':'); do\n" +
        "  case \"\$pkg\" in\n" +
        "    $pat) ;;\n" +
        "    *) am force-stop \"\$pkg\" ;;\n" +
        "  esac\n" +
        "done\n" +
        "echo \"Background apps closed\""
}
