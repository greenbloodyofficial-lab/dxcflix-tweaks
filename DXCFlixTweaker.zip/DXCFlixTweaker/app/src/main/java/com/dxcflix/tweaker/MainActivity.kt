package com.dxcflix.tweaker

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NEED_PERMISSION, READY }

class MainActivity : ComponentActivity() {

    private val shizukuState = mutableStateOf(ShizukuState.NOT_RUNNING)

    private val onBinder = Shizuku.OnBinderReceivedListener { refreshState() }
    private val onDead = Shizuku.OnBinderDeadListener { refreshState() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshState() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refreshState()

        setContent {
            App(
                state = shizukuState.value,
                onRequestPermission = {
                    try { Shizuku.requestPermission(0) } catch (_: Throwable) {}
                },
                onRefresh = { refreshState() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    private fun refreshState() {
        shizukuState.value = try {
            when {
                !Shizuku.pingBinder() -> ShizukuState.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.READY
                else -> ShizukuState.NEED_PERMISSION
            }
        } catch (_: Throwable) {
            ShizukuState.NOT_RUNNING
        }
    }
}

@Composable
fun App(
    state: ShizukuState,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tweaks", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val toggles = remember {
        mutableStateMapOf<String, Boolean>().apply {
            TWEAKS.forEach { put(it.id, prefs.getBoolean(it.id, false)) }
        }
    }
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun append(text: String) {
        log = (text + "\n\n" + log).take(6000)
    }

    fun exec(label: String, script: String, after: (() -> Unit)? = null) {
        if (state != ShizukuState.READY) {
            append("Shizuku is not ready - start Shizuku and grant permission first.")
            return
        }
        scope.launch {
            busy = true
            val out = withContext(Dispatchers.IO) { Shell.run(script) }
            append("> $label\n$out")
            after?.invoke()
            busy = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("DXCFlix Tweaker", fontSize = 24.sp, style = MaterialTheme.typography.headlineSmall)
                    Text("Powered by DXCFlix STUDIO", fontSize = 12.sp)
                }

                // ---- Shizuku status ----
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            val text = when (state) {
                                ShizukuState.NOT_RUNNING -> "Shizuku is not running. Start it (Wireless debugging) then tap Refresh."
                                ShizukuState.NEED_PERMISSION -> "Shizuku is running. Permission needed."
                                ShizukuState.READY -> "Shizuku connected - ready."
                            }
                            Text(text)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = onRefresh) { Text("Refresh") }
                                if (state == ShizukuState.NEED_PERMISSION) {
                                    Button(onClick = onRequestPermission) { Text("Grant permission") }
                                }
                            }
                        }
                    }
                }

                // ---- One-tap actions ----
                item {
                    Text("Actions", style = MaterialTheme.typography.titleMedium)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(enabled = !busy, onClick = { exec("RAM cleanup", RAM_CLEAN_SCRIPT) }) { Text("RAM clean") }
                        Button(enabled = !busy, onClick = { exec("Force stop background apps", forceStopScript()) }) { Text("Stop BG apps") }
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(enabled = !busy, onClick = { exec("Device info", INFO_SCRIPT) }) { Text("Device info") }
                        OutlinedButton(enabled = !busy, onClick = {
                            val script = TWEAKS.flatMap { it.off }.joinToString("\n")
                            exec("Reset ALL to default", script) {
                                TWEAKS.forEach {
                                    toggles[it.id] = false
                                    prefs.edit().putBoolean(it.id, false).apply()
                                }
                            }
                        }) { Text("Reset all") }
                    }
                }

                // ---- Toggles grouped ----
                TWEAKS.groupBy { it.group }.forEach { (group, list) ->
                    item {
                        Text(group, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                    }
                    items(list, key = { it.id }) { t ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(t.title, style = MaterialTheme.typography.bodyLarge)
                                    Text(t.desc, fontSize = 12.sp)
                                }
                                Switch(
                                    checked = toggles[t.id] == true,
                                    enabled = !busy,
                                    onCheckedChange = { want ->
                                        val script = (if (want) t.on else t.off).joinToString("\n")
                                        exec("${t.title} -> ${if (want) "ON" else "OFF"}", script) {
                                            toggles[t.id] = want
                                            prefs.edit().putBoolean(t.id, want).apply()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // ---- Log ----
                item {
                    Text("Output log", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                    Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Text(
                            if (log.isEmpty()) "(empty)" else log,
                            modifier = Modifier.padding(12.dp),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
