# DXCFlix OPT

Universal Android optimization dashboard with a dark green glass-style interface, device information, Shizuku shell execution, Free Fire launch shortcuts, and GitHub Actions APK build.

## Build with GitHub Actions
1. Extract this ZIP on your computer or phone.
2. Upload **the contents inside `DXCFlixOPT/`** to the root of a new GitHub repository (including the hidden `.github` folder).
3. Open **Actions** in GitHub. The `Build DXCFlix OPT APK` workflow runs on push; you can also select **Run workflow**.
4. Download `DXCFlixOPT-debug` from the completed workflow run's Artifacts section.

The generated debug APK is unsigned for Play Store distribution, but can be installed manually after enabling installation from that source.

## Shizuku setup
1. Install and start Shizuku.
2. Start its wireless debugging/ADB service (or root mode).
3. Open DXCFlix OPT and tap **Connect / Request permission**.
4. Grant the Shizuku permission prompt.

Commands run only after Shizuku is available and permission is granted.

## Notes / limitations
- This starter uses Shizuku's `newProcess` shell API for straightforward command execution. Shizuku's API documentation recommends migrating long-term implementations to UserService; this project keeps the shell runner small and transparent.
- Toggle state records the last state requested inside this app. Android/OEM restrictions can reject individual settings; check the command output shown in the app.
- The provided reset commands restore the defaults supplied by the project, not necessarily each phone's previous personal values.
- `touch_acceleration` and `thermalservice` commands may not exist on many devices. They are attempted as supplied and may be ignored.
- Free Fire package IDs can differ by region/build. The app checks `com.dts.freefireth` and `com.dts.freefiremax`.
- The "Kill Background Apps" action is powerful: it force-stops third-party packages except the exclusions in the supplied script. Review the list before running.
- RAM/CPU/device details are read from Android system APIs and `/proc/cpuinfo`; some OEMs restrict CPU details.
