package com.dxcflix.opt

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(4, 10, 7)
    private val panel = Color.rgb(13, 29, 20)
    private val green = Color.rgb(0, 230, 118)
    private val muted = Color.rgb(155, 180, 164)
    private val prefs by lazy { getSharedPreferences("dxcflix_opt", Context.MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var statusText: TextView
    private lateinit var root: LinearLayout
    private val switches = mutableListOf<Switch>()

    private val touchOn = """
settings put system pointer_speed 7
settings put secure long_press_timeout 150
settings put secure multi_press_timeout 150
settings put secure touch_acceleration 1 2>/dev/null
""".trimIndent()
    private val touchOff = """
settings put system pointer_speed 0
settings put secure long_press_timeout 400
settings put secure multi_press_timeout 300
settings put secure touch_acceleration 0 2>/dev/null
""".trimIndent()
    private val animOn = """
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
""".trimIndent()
    private val animOff = """
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
""".trimIndent()
    private val gameOn = """
am set-standby-bucket com.dts.freefireth active 2>/dev/null
am set-standby-bucket com.dts.freefiremax active 2>/dev/null
""".trimIndent()
    private val gameOff = """
am set-standby-bucket com.dts.freefireth working_set 2>/dev/null
am set-standby-bucket com.dts.freefiremax working_set 2>/dev/null
""".trimIndent()
    private val batteryOn = """
settings put global low_power_mode 0
settings put global low_power_mode_sticky 0
""".trimIndent()
    private val batteryOff = """
settings delete global low_power_mode_sticky 2>/dev/null
settings put global adaptive_battery_management_enabled 1 2>/dev/null
""".trimIndent()
    private val networkOn = """
settings put global mobile_data_always_on 1
settings put global network_scoring_ui_enabled 0 2>/dev/null
""".trimIndent()
    private val networkOff = """
settings delete global mobile_data_always_on 2>/dev/null
settings delete global network_scoring_ui_enabled 2>/dev/null
""".trimIndent()
    private val cleanScript = """
sync
pm trim-caches 999G 2>/dev/null
am kill-all 2>/dev/null
cmd activity kill-all 2>/dev/null
""".trimIndent()
    private val killScript = """
CURRENT_IME=$(settings get secure default_input_method 2>/dev/null | cut -d'/' -f1)
CURRENT_HOME=$(cmd package resolve-activity --brief -c android.intent.category.HOME 2>/dev/null | tail -n 1 | cut -d'/' -f1)
for pkg in $(pm list packages -3 2>/dev/null | cut -f 2 -d ":"); do
  case "${'$'}pkg" in
    com.dts.freefireth|com.dts.freefiremax|moe.shizuku.privileged.api|in.sunilpaulmathew.ashell|me.piebridge.brevent|com.google.android.gms|com.google.android.gsf|com.google.android.inputmethod.latin|"${'$'}CURRENT_IME"|"${'$'}CURRENT_HOME") ;;
    *) am force-stop "${'$'}pkg" 2>/dev/null ;;
  esac
done
""".trimIndent()
    private val resetScript = """
settings put system pointer_speed 0
settings put secure long_press_timeout 400
settings put secure multi_press_timeout 300
settings put secure touch_acceleration 0 2>/dev/null
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings delete global low_power_mode_sticky 2>/dev/null
settings put global low_power_trigger_level 15 2>/dev/null
settings put global adaptive_battery_management_enabled 1 2>/dev/null
cmd power set-mode 0 2>/dev/null
settings delete global mobile_data_always_on 2>/dev/null
settings delete global network_scoring_ui_enabled 2>/dev/null
settings put global wifi_sleep_policy 2 2>/dev/null
settings put global wifi_scan_always_enabled 1 2>/dev/null
am set-standby-bucket com.dts.freefireth working_set 2>/dev/null
am set-standby-bucket com.dts.freefiremax working_set 2>/dev/null
cmd thermalservice reset 2>/dev/null
settings put global thermal_mitigation_ready 1 2>/dev/null
""".trimIndent()

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 1001) {
            refreshShizuku()
            toast(if (grantResult == PackageManager.PERMISSION_GRANTED) "Shizuku permission granted" else "Shizuku permission denied")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        refreshShizuku()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        worker.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            val id = resources.getIdentifier("dxcflix_logo", "drawable", packageName)
            if (id != 0) setImageResource(id)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, green, 100)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brand.addView(text("DXCFlix OPT", 26f, Color.WHITE, true))
        brand.addView(text("UNIVERSAL ANDROID OPTIMIZER", 10f, green, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        statusText = text("Checking Shizuku…", 13f, muted, true)
        val statusCard = card()
        statusCard.addView(statusText)
        val connect = actionButton("CONNECT / REQUEST SHIZUKU")
        connect.setOnClickListener { requestShizuku() }
        statusCard.addView(connect)
        root.addView(statusCard)

        section("DEVICE INFORMATION")
        val info = card()
        val ram = getRamInfo()
        info.addView(text("MODEL     ${Build.MANUFACTURER} ${Build.MODEL}", 14f, Color.WHITE, true))
        info.addView(text("ANDROID  ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", 13f, muted, false))
        info.addView(text("RAM          $ram", 13f, muted, false))
        info.addView(text("CPU          ${cpuName()}", 12f, muted, false))
        info.addView(text("ABI            ${Build.SUPPORTED_ABIS.joinToString()}", 12f, muted, false))
        root.addView(info)

        section("OPTIMIZATION CONTROLS")
        addToggle("Touch & Pointer Boost", "Improve touch response", touchOn, touchOff, 0)
        addToggle("Fast UI Animations", "Faster system animations", animOn, animOff, 1)
        addToggle("Free Fire Priority Mode", "Game standby priority", gameOn, gameOff, 2)
        addToggle("Disable Battery Saver", "Disable low power mode", batteryOn, batteryOff, 3)
        addToggle("Network Keep-Alive", "Keep mobile data active", networkOn, networkOff, 4)

        section("GAME LAUNCHERS")
        addGameButton("🔥  OPEN FREE FIRE", "com.dts.freefireth")
        addGameButton("⚡  OPEN FREE FIRE MAX", "com.dts.freefiremax")

        section("INSTANT ACTIONS")
        addActionCard("Clean RAM & Cache", "One-tap cleanup", cleanScript, false)
        addActionCard("Kill Background Apps", "Force-stop third-party apps except protected packages", killScript, true)

        val reset = actionButton("↻  RESET ALL TO DEFAULT")
        reset.setBackground(rounded(Color.rgb(55, 12, 15), Color.rgb(255, 65, 65), 18))
        reset.setTextColor(Color.WHITE)
        reset.setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("Reset all settings?")
                .setMessage("This runs the reset commands you supplied. It restores the project's defaults, not necessarily your phone's previous custom values.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("RESET") { _, _ ->
                    runShell(resetScript) { ok, output ->
                        switches.forEachIndexed { i, sw -> sw.isChecked = false; prefs.edit().putBoolean("toggle_$i", false).apply() }
                        showResult("Master Reset", ok, output)
                    }
                }.show()
        }
        root.addView(reset)
        val channel = actionButton("▶  YouTube  @dxcflixstudio")
        channel.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/@dxcflixstudio"))) }
        root.addView(channel)
        root.addView(text("Created by DXCFlix Studio  •  v1.0", 11f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })
    }

    private fun addToggle(title: String, subtitle: String, on: String, off: String, index: Int) {
        val box = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(title, 15f, Color.WHITE, true))
        labels.addView(text(subtitle, 11f, muted, false))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
            isChecked = prefs.getBoolean("toggle_$index", false)
        }
        sw.setOnCheckedChangeListener { _, checked ->
            runShell(if (checked) on else off) { ok, output ->
                if (ok) prefs.edit().putBoolean("toggle_$index", checked).apply()
                else {
                    sw.setOnCheckedChangeListener(null)
                    sw.isChecked = !checked
                    sw.setOnCheckedChangeListener { _, v ->
                        runShell(if (v) on else off) { success, out ->
                            if (success) prefs.edit().putBoolean("toggle_$index", v).apply()
                            else toast("Command failed: check Shizuku / device support")
                        }
                    }
                }
                if (!ok) showResult(title, false, output)
            }
        }
        row.addView(sw)
        box.addView(row)
        root.addView(box)
        switches.add(sw)
    }

    private fun addGameButton(label: String, pkg: String) {
        val b = actionButton(label)
        b.setOnClickListener {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) startActivity(launch)
            else toast("Game not installed (package: $pkg)")
        }
        root.addView(b)
    }

    private fun addActionCard(title: String, subtitle: String, script: String, confirm: Boolean) {
        val box = card()
        box.addView(text(title, 16f, Color.WHITE, true))
        box.addView(text(subtitle, 11f, muted, false))
        val b = actionButton("RUN NOW")
        b.setOnClickListener {
            val run = { runShell(script) { ok, output -> showResult(title, ok, output) } }
            if (confirm) android.app.AlertDialog.Builder(this)
                .setTitle("Kill background apps?")
                .setMessage("This force-stops most third-party apps. Unsaved work in those apps may be lost.")
                .setNegativeButton("CANCEL", null).setPositiveButton("RUN") { _, _ -> run() }.show()
            else run()
        }
        box.addView(b)
        root.addView(box)
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { toast("Start Shizuku service first"); refreshShizuku(); return }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku permission already granted")
            } else Shizuku.requestPermission(1001)
            refreshShizuku()
        } catch (e: Exception) { toast("Shizuku unavailable: ${e.message}") }
    }

    private fun refreshShizuku() {
        val connected = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        val granted = try { connected && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
        statusText.text = when {
            !connected -> "● SHIZUKU DISCONNECTED — start Shizuku service"
            granted -> "● SHIZUKU CONNECTED — permission granted"
            else -> "● SHIZUKU CONNECTED — permission required"
        }
        statusText.setTextColor(if (granted) green else Color.rgb(255, 190, 70))
    }

    private fun runShell(script: String, done: (Boolean, String) -> Unit) {
        val connected = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        val granted = try { connected && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
        if (!connected || !granted) { toast("Connect Shizuku and grant permission first"); refreshShizuku(); return }
        worker.execute {
            var output = ""
            var success = false
            try {
                // Shizuku API 13 makes newProcess private. Invoke it reflectively
                // for this simple shell runner; UserService is the long-term API.
                val method = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                ).apply { isAccessible = true }
                val process = method.invoke(
                    null,
                    arrayOf("sh", "-c", script),
                    null,
                    null
                ) as Process
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val code = process.waitFor()
                output = (stdout + "\n" + stderr + "\nExit code: " + code).trim()
                success = code == 0
            } catch (e: Exception) { output = e.toString() }
            runOnUiThread { done(success, output.ifBlank { if (success) "Commands completed." else "No output. Some commands may be unsupported." }) }
        }
    }

    private fun showResult(title: String, ok: Boolean, output: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("$title — ${if (ok) "Finished" else "Check result"}")
            .setMessage(output.take(3500))
            .setPositiveButton("OK", null).show()
    }

    private fun getRamInfo(): String {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024L * 1024L)
        val avail = mi.availMem / (1024L * 1024L)
        return "${(total / 1024.0).toInt()} GB total • ${avail} MB free"
    }

    private fun cpuName(): String = try {
        val line = java.io.File("/proc/cpuinfo").readLines().firstOrNull {
            it.startsWith("Hardware", true) || it.startsWith("model name", true) || it.startsWith("Processor", true)
        }
        line?.substringAfter(':')?.trim()?.take(48) ?: Build.HARDWARE
    } catch (_: Exception) { Build.HARDWARE }

    private fun section(label: String) {
        val t = text(label, 15f, green, true)
        t.setPadding(dp(3), dp(18), 0, dp(7))
        root.addView(t)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = rounded(panel, Color.rgb(38, 100, 65), 18)
        elevation = dp(3).toFloat()
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        layoutParams = lp
    }

    private fun actionButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.BLACK)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(green, green, 16)
        isAllCaps = false
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        layoutParams = lp
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun rounded(color: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
