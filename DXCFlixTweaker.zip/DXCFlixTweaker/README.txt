DXCFlix Tweaker - build steps
1. Install Android Studio (latest), File > Open > select this folder.
2. Let Gradle sync finish (needs internet the first time).
3. Build > Build APK(s)  (or Run on your phone).
4. On the phone: start Shizuku (Wireless debugging), open the app, tap "Grant permission".
Each switch: ON runs the commands from Script/run, OFF runs the commands from Script/stop.
